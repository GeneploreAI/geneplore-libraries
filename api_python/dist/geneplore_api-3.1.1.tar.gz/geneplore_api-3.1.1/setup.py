from setuptools import setup

setup(
    name='geneplore_api',
    version='3.1.1',
    install_requires=[
        'requests'
    ],
    test_suite="tests",
)